-- phpMyAdmin SQL Dump
-- version 3.5.3
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.27
-- Versão do PHP: 5.4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `apphibernate`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `autor`
--

CREATE TABLE IF NOT EXISTS `autor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `autorlivro`
--

CREATE TABLE IF NOT EXISTS `autorlivro` (
  `autorid` int(11) NOT NULL,
  `livroid` int(11) NOT NULL,
  PRIMARY KEY (`autorid`,`livroid`),
  KEY `pkautor_idx` (`autorid`),
  KEY `pklivro_idx` (`livroid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `data` date DEFAULT NULL,
  `hora` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `valor` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gente`
--

CREATE TABLE IF NOT EXISTS `gente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gentefisica`
--

CREATE TABLE IF NOT EXISTS `gentefisica` (
  `genteid` int(11) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  PRIMARY KEY (`genteid`),
  KEY `pkfisicagente_idx` (`genteid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gentejuridica`
--

CREATE TABLE IF NOT EXISTS `gentejuridica` (
  `genteid` int(11) NOT NULL,
  `cnpj` varchar(20) NOT NULL,
  PRIMARY KEY (`genteid`),
  KEY `pkjuridicagente_idx` (`genteid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE IF NOT EXISTS `livro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `telefone`
--

CREATE TABLE IF NOT EXISTS `telefone` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `ddd` varchar(255) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  `codigocliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `FK_telefone_codigocliente` (`codigocliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `autorlivro`
--
ALTER TABLE `autorlivro`
  ADD CONSTRAINT `pkautor` FOREIGN KEY (`autorid`) REFERENCES `autor` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pklivro` FOREIGN KEY (`livroid`) REFERENCES `livro` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para a tabela `gentefisica`
--
ALTER TABLE `gentefisica`
  ADD CONSTRAINT `pkfisicagente` FOREIGN KEY (`genteid`) REFERENCES `gente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para a tabela `gentejuridica`
--
ALTER TABLE `gentejuridica`
  ADD CONSTRAINT `pkjuridicagente` FOREIGN KEY (`genteid`) REFERENCES `gente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para a tabela `telefone`
--
ALTER TABLE `telefone`
  ADD CONSTRAINT `FK_telefone_codigocliente` FOREIGN KEY (`codigocliente`) REFERENCES `cliente` (`codigo`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
